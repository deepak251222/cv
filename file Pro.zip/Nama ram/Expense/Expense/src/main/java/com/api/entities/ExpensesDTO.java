package com.api.entities;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExpensesDTO {
	
	private long expenseAmount;
	private int tax;
	private String vendors;
	private long category;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	private LocalDate date;
	@Lob
	private String notes;

}
