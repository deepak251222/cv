package com.api.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.entities.Category;
import com.api.exception.ResourceNotFoundException;
import com.api.repository.CategoriesRepository;
import com.api.service.CategoriesService;

@Service
public class CategoriesServiceImpl implements CategoriesService {

    private final CategoriesRepository categoriesRepository;

    @Autowired
    public CategoriesServiceImpl(CategoriesRepository categoriesRepository) {
        this.categoriesRepository = categoriesRepository;
    }

    @Override
    public Category getCategories(long categoryId) {
        return categoriesRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with ID: " + categoryId));
    }

    @Override
    public boolean deleteCategories(long categoryId) {
        Optional<Category> category = categoriesRepository.findById(categoryId);
        category
    			.orElseThrow(() -> new ResourceNotFoundException("Category not found with ID: " + categoryId));
        if (category.isPresent()) {
        	
            categoriesRepository.delete(category.get());
            return true;
        }
        return false;
    }

    @Override
    public Category createCategories(Category categories) {
        return categoriesRepository.save(categories);
    }

    @Override
    public Category update(Category updatedCategories, long categoryId) {
        Category category = categoriesRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with ID: " + categoryId));

        category.setCategoryName(updatedCategories.getCategoryName());
        category.setExpense(updatedCategories.isExpense());
        category.setIncome(updatedCategories.isIncome());

        return categoriesRepository.save(category);
    }

    @Override
    public List<Category> getAllCategories() {
        List<Category> categoriesList = categoriesRepository.findAll();
        if (categoriesList.isEmpty()) {
            throw new RuntimeException("No categories found in the database.");
        }
        return categoriesList;
    }
}
