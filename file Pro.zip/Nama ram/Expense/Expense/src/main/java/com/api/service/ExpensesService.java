package com.api.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.api.entities.Expenses;
import com.api.entities.ExpensesDTO;

public interface ExpensesService {

	boolean deleteExpenses(long expensesId);

	Expenses updateExpenses(Expenses expenses, long expensesId, MultipartFile file, long categoryId) throws IOException;

	Map<String, Object> getExpensesWithFile(long expensesId) throws Exception;

	List<Map<String, Object>> getAllExpensesWithFiles();

	Expenses saveExpenses(Expenses expenses, MultipartFile file, long categoryId) throws IOException;

	Expenses createExpenses(ExpensesDTO expensesDTO, MultipartFile file) throws IOException;

	Expenses putExpenses(ExpensesDTO expensesDTO, long expensesId, MultipartFile file) throws IOException;

}
