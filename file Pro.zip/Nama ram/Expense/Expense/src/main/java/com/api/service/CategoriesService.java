package com.api.service;

import java.util.List;

import com.api.entities.Category;

public interface CategoriesService {

	Category getCategories(long categoryId);

	boolean deleteCategories(long categoryId);

	Category createCategories(Category categories);

	Category update(Category categories, long categoryId);

	List<Category> getAllCategories();

}
