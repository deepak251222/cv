package com.api.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.api.entities.Expenses;
import com.api.entities.ExpensesDTO;
import com.api.service.ExpensesService;
@RestController
public class ExpensesController {

    private final ExpensesService expensesService;

    @Autowired
    public ExpensesController(ExpensesService expensesService) {
        this.expensesService = expensesService;
    }

    @GetMapping("/expenses/{expensesId}")
    public ResponseEntity<?> getExpenses(@PathVariable long expensesId) throws Exception {
        Map<String, Object> expensesWithFile = expensesService.getExpensesWithFile(expensesId);
        return ResponseEntity.ok(expensesWithFile);
    }

    @PostMapping("/{categoryId}/expenses/create")
    public ResponseEntity<?> saveExpenses(@ModelAttribute Expenses expenses,
                                                  @RequestParam("file") MultipartFile File,
                                                  @PathVariable("categoryId") long categoryId) throws IOException {
    
    	Expenses createdExpenses = expensesService.saveExpenses(expenses, File, categoryId);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdExpenses);
   
    }

    @PutMapping("/{categoryId}/expenses/{expensesId}")
    public ResponseEntity<Expenses> updateExpenses(@PathVariable long expensesId,
                                                  @ModelAttribute Expenses updatedExpenses,
                                                  @RequestParam("file") MultipartFile file,
                                                  @PathVariable("categoryId") long categoryId) throws IOException {
        Expenses updatedExpense = expensesService.updateExpenses(updatedExpenses, expensesId, file, categoryId);
        return ResponseEntity.ok(updatedExpense);
    }

    @GetMapping("/expenses")
    public ResponseEntity<List<Map<String, Object>>> getAllExpensesWithFiles() {
        List<Map<String, Object>> expensesWithFiles = expensesService.getAllExpensesWithFiles();
        return ResponseEntity.ok(expensesWithFiles);
    }

    @DeleteMapping("/expenses/{expensesId}")
    public ResponseEntity<String> deleteExpenses(@PathVariable long expensesId) {
        boolean isDeleted = expensesService.deleteExpenses(expensesId);
        if (isDeleted) {
            return ResponseEntity.ok("Expenses deleted successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/expenses/create")
    public ResponseEntity<?> createExpenses(@ModelAttribute ExpensesDTO expenses,
                                                  @RequestParam("file") MultipartFile File
                                                  ) throws IOException {
    
    	Expenses createdExpenses = expensesService.createExpenses(expenses, File);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdExpenses);
   
    }
    @PutMapping("/expenses/{expensesId}")
    public ResponseEntity<Expenses> putExpenses(@PathVariable long expensesId,
                                                  @ModelAttribute ExpensesDTO updatedExpenses,
                                                  @RequestParam("file") MultipartFile file
                                                  ) throws IOException {
        Expenses updatedExpense = expensesService.putExpenses(updatedExpenses, expensesId, file);
        return ResponseEntity.ok(updatedExpense);
    }
}

