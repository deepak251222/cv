package com.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.api.entities.Category;
import com.api.service.CategoriesService;

@RestController
public class CategoriesController {


	
	private CategoriesService categoriesService;
	
	@Autowired
	public CategoriesController(CategoriesService categoriesService) {
		super();
		this.categoriesService = categoriesService;
	}

	@PostMapping("/categories/create")
    public ResponseEntity<?> createCategories( @RequestBody Category categories){
		try {   
			Category categorie= categoriesService.createCategories(categories);
        return ResponseEntity.ok(categorie);
		} catch (Exception e) {
			return ResponseEntity.internalServerError().body("Error create categorie");
		}
    }
	
	 @PutMapping("/categories/{categoryId}")
	 
	    public ResponseEntity<?> updateCategories (@RequestBody Category categories,@PathVariable long categoryId) {
		  
			  Category categorie = categoriesService.update(categories, categoryId);
	        if (categorie != null) {
	            return ResponseEntity.ok(categorie);
	        }
	        return ResponseEntity.notFound().build();
	 
		    }
	 
	 @DeleteMapping("/categories/{categoryId}")
	  
	    public ResponseEntity<?> deleteCategories(@PathVariable long categoryId) {
		  
	        boolean deleted = categoriesService.deleteCategories(categoryId);
	        if (deleted) {
	            return  ResponseEntity.ok("deleted successfully");
	        }
	        return ResponseEntity.notFound().build();
		  
		    }
	  
	  @GetMapping("/get/categories/{categoryId}")
	 
	    public ResponseEntity<?> getCategoriesById(@PathVariable long categoryId) {
		  
			Category categories = categoriesService.getCategories(categoryId);
	        if (categories != null) {
	            return ResponseEntity.ok(categories);
	        }
	        return ResponseEntity.notFound().build();
		 
		    }
	  
	  @GetMapping("/get/categories")
	  
	    public ResponseEntity<?> getAllCategories() {
		  
			  List<Category> categories = categoriesService.getAllCategories();
		  
	        return ResponseEntity.ok(categories);
	 
	    }
}
