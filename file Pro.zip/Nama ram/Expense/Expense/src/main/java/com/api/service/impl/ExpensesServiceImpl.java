package com.api.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.api.entities.Category;
import com.api.entities.Expenses;
import com.api.entities.ExpensesDTO;
import com.api.exception.ResourceNotFoundException;
import com.api.repository.CategoriesRepository;
import com.api.repository.ExpensesRepository;
import com.api.service.ExpensesService;

@Service
public class ExpensesServiceImpl implements ExpensesService {

	private ExpensesRepository expensesRepository;
	private CategoriesRepository categoriesRepository;

	@Autowired
	public ExpensesServiceImpl(ExpensesRepository expensesRepository, CategoriesRepository categoriesRepository) {
		super();
		this.expensesRepository = expensesRepository;
		this.categoriesRepository = categoriesRepository;
	}

	@Override
	public Map<String, Object> getExpensesWithFile(long expensesId) throws Exception {
		Optional<Expenses> expenses = expensesRepository.findById(expensesId);
		if (expenses.isEmpty()) {
			throw new ResourceNotFoundException("Expenses not found with ID: " + expensesId);
		}

		Expenses expensesObj = expenses.get();

		Map<String, Object> result = new HashMap<>();
		result.put("expenses", expensesObj);

		String file = expensesObj.getFiles();
		byte[] fileBytes = null;
		if (file != null) {
			fileBytes = Base64.getDecoder().decode(file);
			String filePath = "C:\\Users\\Ram\\Downloads\\Expense\\Expense\\src\\main\\resources\\file\\"
					+ expensesObj.getExpensesId()+"-" + expensesObj.getOriginalFilename();
			try {
				FileOutputStream fos = new FileOutputStream(filePath);
				fos.write(fileBytes);
				fos.close();
				result.put("filePath", filePath);
			} catch (IOException e) {
				throw new RuntimeException("Failed to write file: " + e.getMessage(), e);
			}
		}
		return result;
	}

	@Override
	public Expenses saveExpenses(Expenses expenses, MultipartFile file, long categoryId) throws IOException {
		Category categories = categoriesRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Categories not found with ID: " + categoryId));

		if (file != null && !file.isEmpty()) {
			byte[] bytes = file.getBytes();
			String encodeToString = Base64.getEncoder().encodeToString(bytes);
			expenses.setFiles(encodeToString);
			String originalFilename = file.getOriginalFilename();
			expenses.setOriginalFilename(originalFilename);
		}

		expenses.setCategory(categories);
		return expensesRepository.save(expenses);
	}

	@Override
	public boolean deleteExpenses(long expensesId) {
		Optional<Expenses> expenses = expensesRepository.findById(expensesId);
		expenses.orElseThrow(() -> new ResourceNotFoundException("Expenses not found with ID: " + expensesId));
		if (expenses.isPresent()) {
			expensesRepository.deleteById(expensesId);;
			return true;
		}
		return false;
	}

	@Override
	public Expenses updateExpenses(Expenses updatedExpenses, long expensesId, MultipartFile file, long categoryId)
			throws IOException {
		Expenses expense = expensesRepository.findById(expensesId)
				.orElseThrow(() -> new ResourceNotFoundException("Expenses not found with ID: " + expensesId));

		Category categories = categoriesRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Categories not found with ID: " + categoryId));

		expense.setDate(updatedExpenses.getDate());
		expense.setExpenseAmount(updatedExpenses.getExpenseAmount());
		expense.setCategory(categories);
		expense.setNotes(updatedExpenses.getNotes());
		expense.setTax(updatedExpenses.getTax());
		expense.setVendors(updatedExpenses.getVendors());

		if (file != null && !file.isEmpty()) {
			byte[] fileBytes = file.getBytes();
			String encodeToString = Base64.getEncoder().encodeToString(fileBytes);
			expense.setFiles(encodeToString);
			expense.setOriginalFilename(file.getOriginalFilename());
		}

		return expensesRepository.save(expense);
	}

	@Override
	public List<Map<String, Object>> getAllExpensesWithFiles() {
		List<Expenses> expensesList = expensesRepository.findAll();
		if (expensesList.isEmpty()) {
			throw new RuntimeException("No expenses found in the database.");
		}

		List<Map<String, Object>> results = new ArrayList<>();

		for (Expenses expenses : expensesList) {

			Map<String, Object> result = new HashMap<>();
			result.put("expenses", expenses);

			String file = expenses.getFiles();
			byte[] fileBytes = null;
			if (file != null) {
				fileBytes = Base64.getDecoder().decode(file);

				String filePath = "C:\\Users\\Ram\\Downloads\\Expense\\Expense\\src\\main\\resources\\file\\"
						+ expenses.getExpensesId()+"-" + expenses.getOriginalFilename();

				try {
					FileOutputStream fos = new FileOutputStream(filePath);
					fos.write(fileBytes);
					fos.close();
					result.put("filePath", filePath);

				} catch (IOException e) {
					throw new RuntimeException("Failed to write file: " + e.getMessage(), e);
				}
			}
			results.add(result);
		}

		return results;
	}
	@Override
	public Expenses createExpenses(ExpensesDTO expensesDTO, MultipartFile file) throws IOException {
		Category categories = categoriesRepository.findById(expensesDTO.getCategory())
				.orElseThrow(() -> new ResourceNotFoundException("Categories not found with ID: " + expensesDTO.getCategory()));

		Expenses expenses =new Expenses();
		if (file != null && !file.isEmpty()) {
			byte[] bytes = file.getBytes();
			String encodeToString = Base64.getEncoder().encodeToString(bytes);
			expenses.setFiles(encodeToString);
			String originalFilename = file.getOriginalFilename();
			expenses.setOriginalFilename(originalFilename);
		}

		expenses.setCategory(categories);
		expenses.setDate(expensesDTO.getDate());
		expenses.setExpenseAmount(expensesDTO.getExpenseAmount());
		expenses.setNotes(expensesDTO.getNotes());
		expenses.setTax(expensesDTO.getTax());
		expenses.setVendors(expensesDTO.getVendors());
		return expensesRepository.save(expenses);
	}
	
	@Override
	public Expenses putExpenses(ExpensesDTO expensesDTO, long expensesId, MultipartFile file)
			throws IOException {
		Expenses expense = expensesRepository.findById(expensesId)
				.orElseThrow(() -> new ResourceNotFoundException("Expenses not found with ID: " + expensesId));

		Category categories = categoriesRepository.findById(expensesDTO.getCategory())
				.orElseThrow(() -> new ResourceNotFoundException("Categories not found with ID: " + expensesDTO.getCategory()));
		expense.setDate(expensesDTO.getDate());
		expense.setExpenseAmount(expensesDTO.getExpenseAmount());
		expense.setCategory(categories);
		expense.setNotes(expensesDTO.getNotes());
		expense.setTax(expensesDTO.getTax());
		expense.setVendors(expensesDTO.getVendors());

		if (file != null && !file.isEmpty()) {
			byte[] fileBytes = file.getBytes();
			String encodeToString = Base64.getEncoder().encodeToString(fileBytes);
			expense.setFiles(encodeToString);
			expense.setOriginalFilename(file.getOriginalFilename());
		}

		return expensesRepository.save(expense);
	}

}
